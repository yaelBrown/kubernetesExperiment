package com.example.kubernetesspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KubernetesSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(KubernetesSpringApplication.class, args);
	}

}
