package com.example.kubernetesspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KubernetesSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
